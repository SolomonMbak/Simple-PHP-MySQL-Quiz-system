<?php
include('class/users.php');
$ans=new users;

$answr=$ans->answr($_POST);

?>